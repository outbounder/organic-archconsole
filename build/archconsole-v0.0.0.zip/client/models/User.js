module.exports = Backbone.Model.extend({

});