var WebCell = require("organic-webcell/WebCell");
var instance = new WebCell();